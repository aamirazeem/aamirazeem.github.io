from flask import Flask, render_template, request, redirect, url_for, session, flash
import smtplib
from email.message import EmailMessage
from datetime import datetime
import requests
import os
from werkzeug.security import generate_password_hash, check_password_hash
import secrets

app = Flask(__name__)
app.secret_key = os.environ.get('FLASK_SECRET_KEY', 'your_default_secret_key')

# Use hashed passwords
users = {
    'aamirazeem85@gmail.com': generate_password_hash('Azeem@1996'),
    'jetexconsulting@gmail.com': generate_password_hash('Jetex@1234')
    
}

reset_tokens = {}  # Temporary storage for reset tokens


@app.route('/', methods=['GET'])
def home():
    if 'user' in session:
        return redirect(url_for('dashboard'))
    return render_template('login.html')


@app.route('/login', methods=['POST'])
def login():
    email = request.form.get('email')
    password = request.form.get('password')

    if email in users and check_password_hash(users[email], password):
        session['user'] = email
        send_login_email(email)
        return redirect(url_for('dashboard'))
    else:
        flash("Invalid email or password", "error")
        return redirect(url_for('home'))


@app.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        email = request.form.get('email')
        password = request.form.get('password')

        if email in users:
            flash('Account already exists!', 'error')
        else:
            users[email] = generate_password_hash(password)
            flash('Registration successful! Please login.', 'success')
            return redirect(url_for('home'))
    return render_template('register.html')


@app.route('/forgot-password', methods=['GET', 'POST'])
def forgot_password():
    if request.method == 'POST':
        email = request.form.get('email')

        if email in users:
            # Generate random token
            token = secrets.token_urlsafe(16)
            reset_tokens[email] = token
            send_reset_password_email(email, token)
            flash(f'Reset link sent to {email} (simulated)', 'info')
        else:
            flash('Email not found!', 'error')

    return render_template('forgot_password.html')


@app.route('/reset-password', methods=['GET', 'POST'])
def reset_password():
    email = request.args.get('email')
    token = request.args.get('token')

    if request.method == 'POST':
        new_password = request.form.get('password')
        if email in reset_tokens and reset_tokens[email] == token:
            users[email] = generate_password_hash(new_password)
            reset_tokens.pop(email)
            flash('Password reset successful! Please login.', 'success')
            return redirect(url_for('home'))
        else:
            flash('Invalid or expired reset token.', 'error')

    return render_template('reset_password.html', email=email, token=token)


@app.route('/dashboard', methods=['GET'])
def dashboard():
    if 'user' in session:
        return render_template('dashboard.html', user_email=session['user'])
    return redirect(url_for('home'))


@app.route('/logout', methods=['GET'])
def logout():
    session.pop('user', None)
    flash('You have been logged out.', 'info')
    return redirect(url_for('home'))


def send_login_email(email):
    sender = 'jetexconsulting@gmail.com'
    receiver = 'jetexconsulting@gmail.com'
    app_password = os.environ.get('EMAIL_APP_PASSWORD')

    try:
        ip = requests.get("https://api.ipify.org").text
        location_data = requests.get(f"https://ipapi.co/{ip}/json/").json()
        location = f"{location_data.get('city', '')}, {location_data.get('region', '')}, {location_data.get('country_name', '')}"
    except Exception as e:
        location = "Location not found"
        print("Location fetch error:", e)

    login_time = datetime.now().strftime("%Y-%m-%d %H:%M:%S")

    line = f"📩 Email: {email}\n🕒 Time: {login_time}\n📍 Location: {location}\n{'-'*30}\n"

    msg = EmailMessage()
    msg['Subject'] = '🛡️ Jetex Login Activity'
    msg['From'] = sender
    msg['To'] = receiver
    msg.set_content(line)

    try:
        with smtplib.SMTP_SSL('smtp.gmail.com', 465) as smtp:
            smtp.login(sender, app_password)
            smtp.send_message(msg)
    except Exception as e:
        print("Email sending failed:", e)


def send_reset_password_email(email, token):
    sender = 'jetexconsulting@gmail.com'
    receiver = email
    app_password = os.environ.get('EMAIL_APP_PASSWORD')

    reset_link = f"http://yourdomain.com/reset-password?email={email}&token={token}"
    msg = EmailMessage()
    msg['Subject'] = 'Password Reset Link'
    msg['From'] = sender
    msg['To'] = receiver
    msg.set_content(f'Hello,\n\nPlease use the following link to reset your password:\n{reset_link}\n\nIf you did not request this, please ignore this email.')

    try:
        with smtplib.SMTP_SSL('smtp.gmail.com', 465) as smtp:
            smtp.login(sender, app_password)
            smtp.send_message(msg)
    except Exception as e:
        print("Email sending failed:", e)


if __name__ == '__main__':
    app.run(debug=True)
